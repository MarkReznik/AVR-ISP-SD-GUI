// This file has been prepared for Doxygen automatic documentation generation.
/*! \file ********************************************************************
*
* Atmel Corporation
*
* - File              : Self_programming_main.c
* - Compiler          : IAR EWAVR 2.28a / 3.10c and newer
*
* - Support mail      : avr@atmel.com
*
* - Supported devices : This example is written for ATmega128.
*
* - AppNote           : AVR106 - C functions for reading and writing
*                       to flash memory.
*
* - Description       : The file contains an example program using the Flash R/W
*                       functions provided with the files Self_programming.h /
*                       Self_programming.c . The program should be compiled using
*                       a linker file (*.xcl) that is configured to place the
*                       entire program code into the Boot section of the Flash memory.
*                       Please refer to the application note document for more
*                       information.
*
* $Revision: 2.0 $
* $Date: Wednesday, January 18, 2006 15:18:52 UTC $
*
*****************************************************************************/
#include <ioavr.h>
#include <inavr.h>
#include "Self_programming.h"

__C_task main( void ){
  unsigned char testBuffer1[PAGESIZE];      // Declares variables for testing
  unsigned char testBuffer2[PAGESIZE];      // Note. Each array uses PAGESIZE bytes of
                                            // code stack

  static unsigned char testChar; // A warning will come saying that this var is set but never used. Ignore it.
  int index;
  MCUCR |= (1<<IVSEL);                      // Move interrupt vectors to boot
  RecoverFlash();
  for(index=0; index<PAGESIZE; index++){
    testBuffer1[index]=(unsigned char)index; // Fills testBuffer1 with values 0,1,2..255
  }
  for(;;){
    WriteFlashPage(0x200, testBuffer1);     // Writes testbuffer1 to Flash page 2
                                            // Function returns TRUE
    ReadFlashPage(0x200, testBuffer2);      // Reads back Flash page 2 to TestBuffer2
                                            // Function returns TRUE
    WriteFlashByte(0x204, 0x38);            // Writes 0x38 to byte address 0x204
                                            // Same as byte 4 on page 2
                                            // Returns TRUE
    testChar = ReadFlashByte(0x204);        // Reads back value from address 0x204
  }
}
